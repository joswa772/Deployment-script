@echo off
cd /d E:\USC\DeployScript

C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -ExecutionPolicy Bypass -File deploy.ps1

echo.
echo Closing in 5 seconds...
timeout /t 5 /nobreak >nul
exit
