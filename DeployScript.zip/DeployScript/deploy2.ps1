# ==============================
# CONFIGURATION
# ==============================

$buildFolder      = "E:\Builds"
$archiveFolder    = "E:\Builds\Archive - Updated files"
$projectPath      = "E:\DeployTest\4.7"
$tempExtractPath  = "E:\DeployTest\TempExtract"
$backupPath       = "E:\Backup\4.7_Backup_$(Get-Date -Format 'dd-MM-yyyy')"
$sevenZip         = "C:\Program Files\7-Zip\7z.exe"

$filesToKeep = @(
    "web.config",
    "config",
    "proxy.php",
    "proxy.new.php",
    "proxy.orig.php"
)

$startTime = Get-Date

Clear-Host
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "        BUILD DEPLOYMENT PROCESS"
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""

try {

    # ==============================
    # GET LATEST ZIP
    # ==============================
    $zipFile = Get-ChildItem $buildFolder -Filter *.zip |
               Sort-Object LastWriteTime -Descending |
               Select-Object -First 1

    if ($null -eq $zipFile) {
        throw "No ZIP files found in build folder!"
    }

    $zipPath = $zipFile.FullName
    $buildVersion = [System.IO.Path]::GetFileNameWithoutExtension($zipFile.Name)

    Write-Host "Build Detected  : " -NoNewline
    Write-Host $buildVersion -ForegroundColor Yellow

    if (!(Test-Path $sevenZip)) {
        throw "7-Zip not found!"
    }

    # ==============================
    # PREPARE FOLDERS
    # ==============================
    New-Item -ItemType Directory -Path $archiveFolder -Force | Out-Null
    New-Item -ItemType Directory -Path $tempExtractPath -Force | Out-Null

    # ==============================
    # BACKUP
    # ==============================
    Write-Host "Creating Backup..." -ForegroundColor Green
    Copy-Item $projectPath $backupPath -Recurse -ErrorAction Stop

    # ==============================
    # CLEAN PROJECT (EXCEPT SAFE FILES)
    # ==============================
    Write-Host "Cleaning Old Files..." -ForegroundColor Green
    Get-ChildItem $projectPath | ForEach-Object {
        if ($filesToKeep -notcontains $_.Name) {
            Remove-Item $_.FullName -Recurse -Force -ErrorAction Stop
        }
    }

    # ==============================
    # EXTRACT WITH LIVE PERCENTAGE
    # ==============================
    Write-Host "Extracting Build..." -ForegroundColor Green

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $sevenZip
    $psi.Arguments = "x `"$zipPath`" -o`"$tempExtractPath`" -y -bsp1"
    $psi.RedirectStandardOutput = $true
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $psi
    $process.Start() | Out-Null

    while (-not $process.HasExited) {

        $line = $process.StandardOutput.ReadLine()

        if ($line -match "(\d+)%") {
            Write-Host -NoNewline "`rExtracting: $($matches[1])%   "
        }
    }

    if ($process.ExitCode -ne 0) {
        throw "Extraction failed!"
    }

    Write-Host "`rExtracting: 100%" -ForegroundColor Green

    # ==============================
    # VERIFY EXTRACTION
    # ==============================
    $innerFolder = Get-ChildItem $tempExtractPath | Where-Object { $_.PSIsContainer }

    if ($null -eq $innerFolder) {
        throw "Extraction failed. No inner folder found."
    }

    $fileCount = (Get-ChildItem $innerFolder.FullName -Recurse | Measure-Object).Count
    Write-Host "Files Extracted : $fileCount files" -ForegroundColor Yellow

    # ==============================
    # MOVE FILES
    # ==============================
    Write-Host "Deploying Files..." -ForegroundColor Green
    Get-ChildItem $innerFolder.FullName |
        Move-Item -Destination $projectPath -Force -ErrorAction Stop

    # ==============================
    # CLEAN TEMP
    # ==============================
    Remove-Item $tempExtractPath -Recurse -Force

    # ==============================
    # ARCHIVE ZIP
    # ==============================
    Move-Item $zipPath -Destination $archiveFolder -Force

    $endTime = Get-Date
    $duration = New-TimeSpan -Start $startTime -End $endTime

    Write-Host ""
    Write-Host "=============================================" -ForegroundColor Cyan
    Write-Host " Deployment Completed Successfully " -ForegroundColor Green
    Write-Host " Version        : $buildVersion"
    Write-Host " Duration       : $($duration.Minutes)m $($duration.Seconds)s"
    Write-Host " Backup Created : $backupPath"
    Write-Host "=============================================" -ForegroundColor Cyan
}
catch {

    Write-Host ""
    Write-Host "=============================================" -ForegroundColor Red
    Write-Host " Deployment FAILED "
    Write-Host $_.Exception.Message
    Write-Host "=============================================" -ForegroundColor Red

    if (Test-Path $backupPath) {
        Write-Host "Restoring from backup..." -ForegroundColor Yellow
        Remove-Item $projectPath -Recurse -Force
        Copy-Item $backupPath $projectPath -Recurse
        Write-Host "Rollback completed." -ForegroundColor Green
    }

    exit 1
}
