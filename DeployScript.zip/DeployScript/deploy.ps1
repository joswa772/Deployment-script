$zipPath = "E:\Builds\4.7.zip"
$projectPath = "E:\DeployTest\4.7"
$tempExtractPath = "E:\DeployTest\TempExtract"
$backupPath = "E:\Backup\4.7_latest_Backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"

$filesToKeep = @(
    "web.config",
    "config",
    "proxy.php",
    "proxy.new.php",
    "proxy.orig.php"
)

Write-Host "Starting Deployment..."

if (!(Test-Path $zipPath)) {
    Write-Host "ZIP file not found!"
    exit
}

# Create temp folder
New-Item -ItemType Directory -Path $tempExtractPath -Force | Out-Null

# Backup current project
Write-Host "Creating Backup..."
Copy-Item $projectPath $backupPath -Recurse

# Clean project folder except protected files
Write-Host "Cleaning old files..."
Get-ChildItem $projectPath | ForEach-Object {
    if ($filesToKeep -notcontains $_.Name) {
        Remove-Item $_.FullName -Recurse -Force
    }
}

# Extract ZIP to temp
Write-Host "Extracting ZIP..."
Expand-Archive -Path $zipPath -DestinationPath $tempExtractPath -Force

# Detect inner folder (gbhost)
$innerFolder = Get-ChildItem $tempExtractPath | Where-Object { $_.PSIsContainer }

# Move inner contents to project folder
Write-Host "Moving extracted files..."
Get-ChildItem $innerFolder.FullName | Move-Item -Destination $projectPath -Force

# Remove temp folder
Remove-Item $tempExtractPath -Recurse -Force

Write-Host "Deployment Completed Successfully 🚀"
